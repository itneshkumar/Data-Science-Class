from setuptools import setup, find_packages

setup(
    name="docker-heroku",
    version="0.0.3",
    description="ML project",
    author="Avnish yadav", 
    packages=find_packages(),
    license="MIT"
)